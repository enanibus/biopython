import sys
for aa in sys.argv:
  print(aa)