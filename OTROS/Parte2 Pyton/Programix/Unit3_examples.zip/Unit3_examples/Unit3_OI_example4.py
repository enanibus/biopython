#! /usr/bin/python3 
# HPBBM, Unit 3, example 4: command line arguments

# imports sys module
import sys

# prints all the command line arguments passed to the script
for argumento in sys.argv:
  print(argumento)